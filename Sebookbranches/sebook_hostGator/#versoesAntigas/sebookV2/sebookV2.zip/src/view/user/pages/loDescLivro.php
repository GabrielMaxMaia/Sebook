<article class="livrosL">

	<section class="box-descricao-livro">
		<img src="<?= _URLBASE_ ?>public/img/imgLivro/livroHarry.jpg" alt="">
		<div class="descricaoLivro">
			<h1>Harry Potter</h1>
			<p>
				<strong>Autor:</strong>:JK. ROWLING</p>
			<div class="line-stars">
				<strong>Avaliação:</strong>
				<div class="stars">
					<!-- <img src="<?= _URLBASE_ ?>public/icon/star.png" alt="">
						<img src="<?= _URLBASE_ ?>public/icon/star.png" alt="">
						<img src="<?= _URLBASE_ ?>public/icon/star.png" alt="">

						<img class="empty" src="<?= _URLBASE_ ?>public/icon//starBlack.png" alt="">
						<img class="empty" src="<?= _URLBASE_ ?>public/icon//starBlack.png" alt=""> -->
				</div>
			</div>
		</div>
	</section>
	<section class="sinopse">
		<p>
			<strong>SINOPSE:</strong>
		</p>
		<p>
			Harry Potter e a Câmara Secreta é segundo livro da série Harry Potter. O livro se envolve em torno da lenda de uma câmara
			secreta localizada na Escola de Magia e Bruxaria de Hogwarts, na qual abriga um monstro que matará a todos os bruxos
			que não provém de famílias mágicas. Diversos alunos aparecem petrificados e Harry Potter, além de ser apontado como o
			maior suspeito, tenta desvendar e resolver o mistério junto de seus melhores amigos, Rony Weasley e Hermione Granger.
		</p>
	</section>
	<section class="comentario">
		<div class="person">
			<img src="<?= _URLBASE_ ?>public/icon/user.svg" alt="">
			<div class="descricao-person">
				<strong>paulo_10</strong>
				<div class="stars">
					<!-- <<img src="<?= _URLBASE_ ?>public/icon/star.png" alt="">
							<img src="<?= _URLBASE_ ?>public/icon/star.png" alt="">
							<img src="<?= _URLBASE_ ?>public/icon/star.png" alt="">
							<img class="empty" src="<?= _URLBASE_ ?>public/icon/star.png" alt="">
							<img class="empty" src="<?= _URLBASE_ ?>public/icon/star.png" alt=""> -->
				</div>
			</div>
		</div>
		<p>O filme é muito bom mais o livro é esplêndido!!!!</p>
	</section>
	<section class="comentario">
		<div class="person">
			<img src="<?= _URLBASE_ ?>public/icon/user.svg" alt="">
			<div class="descricao-person">
				<strong>fernada_silva</strong>
				<div class="stars">
					<!-- <img src="<?= _URLBASE_ ?>public/icon/star.png" alt="">
							<img src="<?= _URLBASE_ ?>public/icon/star.png" alt="">
							<img src="<?= _URLBASE_ ?>public/icon/star.png" alt="">
							<img class="empty" src="<?= _URLBASE_ ?>public/icon/star.png" alt="">
							<img class="empty" src="<?= _URLBASE_ ?>public/icon/star.png" alt=""> -->
				</div>
			</div>
		</div>
		<p>Melhor franquia da vida</p>
	</section>

	<h3>Comentario</h3>

	<section class="Cont">
		<div id="Comentar">
			<form>
				<label for="coment"></label>
				<textarea rows="8" cols="50" name="Comentarios" id="coment" maxlength="300" minlength="20"></textarea>

				<input class="btn" type="submit" value="Enviar" />
			</form>
		</div>
	</section>

	<section class="acervo">
		<a href="LogAcervo-sebo.html">
			<h3>JULIO SEBOS</h3>
		</a>
		<div id="Mapa">
			<h3>Maps</h3>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14636.88924717763!2d-46.90127847805996!3d-23.48850077570472!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94cf039ca55b6389%3A0x7ecd38f248fb5c21!2sVila%20Engenho%20Novo%2C%20Barueri%20-%20SP!5e0!3m2!1spt-BR!2sbr!4v1567988811626!5m2!1spt-BR!2sbr">
			</iframe>
		</div>
	</section>

</section>
