<div id="container">
    <div class="banir">
        <h6>INSTRUÇÕES GERAIS: 1) A moderação dos tópicos publicados é feita após provocação (denúncia) e não por censura (prévia); 2) O controle é feito após provocação (denúncia) e avaliando se fere ou não as regras mínimas do site;3) Mensagem em tom
            de ameaça, ofensas ou provocação a um membro do grupo ou a coletividade será, desde que haja denúncia prévia, desativado, excluído ou podendo até - em razão da reincidência - o autor da postagem ser excluído como membro do grupo.</h6>
        <li>
            <a href="#">
                <table border="1">
                    <tr>
                        <th>Data</th>
                        <th>Nome</th>
                        <th>Tipo de usuário</th>
                        <th>Tipo de denúncia</th>
                    </tr>
                    <tr>
                        <td>01/08/2019</td>
                        <td>Zé Fulano Sebos</td>
                        <td>Sebo</td>
                        <td>
                            <label for="excesso">
                            <input name="Excessos de mensagens" id="excesso" type="checkbox">1. Excessos de mensagens, comportamentos repetitivos, anormais:</label>
                            <label for="alheio">
                            <input name="tópicos alheios" id="alheio" type="checkbox">2. Tópicos com temas que fujam do escopo do portal (cunho religioso, político etc):</label>
                            <label for="dados">
                            <input name="Divulgar dados" id="dados" type="checkbox">3. Divulgar dados pessoais e/ou confidenciais:</label>
                            <label for="ameaça">
                            <input name="ameaça, ofensas ou provocação" id="ameaça" type="checkbox">4. Mensagem em tom de ameaça, ofensas ou provocação:</label>
                            <label for="porno">
                            <input name="Postagem pornográfica" id="porno" type="checkbox">5. Postagem pornográfica:</label>
                        </td>
                    </tr>
                </table>
            </a>
        </li>
    </div>
</div>