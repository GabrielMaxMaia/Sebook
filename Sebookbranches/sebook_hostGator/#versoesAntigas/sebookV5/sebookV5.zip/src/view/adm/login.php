<form class='frmLogin' method='post'>
    <input class='inputLogin' type='text' placeholder='Usuário' name='txtUsuario'>
    <input class='inputLogin' type='password' placeholder='Senha' name='txtSenha'>
    <input class='button' type='submit' value='Entrar'>
    <p><a href='#'>Esqueceu a senha?</a></p>
</form>