<div id="container">
    <div class="cadastrarEve">
        <li>
            <a href="#">
                <table border="1">
                    <label for="">Eventos e Notícias</label>
                    <textarea name="eventos e notícias" placeholder="Digite o texto aqui" required="required" cols="30" rows="10"></textarea>
                </table>
            </a>
        </li>
    </div>
</div>