<div id="container">
    <div class="aprovaSebo">
        <li>
            <a href="#">
                <table border="1">
                    <tr>
                        <th>Nome Sebo</th>
                        <th>Data do Cadastro</th>
                        <th>Atendeu todos os requisitos? S/N</th>
                        <th><p>Apovado? : S/N:</p></th>
                        <th>Obervações</th>
                    </tr>
                    <tr>
                        <td>Sebo do Lobão</td>
                        <td>01/08/2019</td>
                        <td>
                            <label for="sim"><input name="atendeu?" id="sim" value="S" type="radio">SIM</label>
                            <label for="nao"><input name="atendeu?" id="nao" value="N" type="radio">NAO</label>
                        </td>
                        <td>
                            <label for="sim"><input name="aprovado ou não" id="sim" value="S" type="radio">SIM</label>
                            <label for="nao"><input name="aprovado ou não" id="nao" value="N" type="radio">NAO</label>
                        </td>
                    </tr>
                    <tr>
                        <td>Ana Sebo</td>
                        <td>03/08/2019</td>
                        <td>
                            <label for="sim"><input name="atendeu?" id="sim" value="S" type="radio">SIM</label>
                            <label for="nao"><input name="atendeu?" id="nao" value="N" type="radio">NAO</label>
                        </td>
                        <td>
                            <label for="sim"><input name="aprovado ou não" id="sim" value="S" type="radio">SIM</label>
                            <label for="nao"><input name="aprovado ou não" id="nao" value="N" type="radio">NAO</label>
                        </td>
                    </tr>
                </table>
            </a>
        </li>
    </div>
</div>