<div class="maisProcurados">
    <div class="container">
        <h1>Mais Procurados</h1>
        <div class="swiper-container">
            <div class="books swiper-wrapper">
                <div class="swiper-slide">
                    <a href="desLivros.html"><img src="<?= _URLBASE_ ?>public/img/imgLivro/livroHarry.jpg" alt="livroHarry" title="Livro"></a>
                </div>
                <div class="swiper-slide">
                    <a href="desLivros2.html"><img src="<?= _URLBASE_ ?>public/img/imgLivro/livroNeve.jpg" alt="livroNeve" title="Livro"></a>
                </div>
                <div class="swiper-slide">
                    <a href="desLivros3.html"><img src="<?= _URLBASE_ ?>public/img/imgLivro/Capa_Como-eu-era-antes-de-voce2.jpg" alt="livroPercy" title="Livro"></a>
                </div>
                <div class="swiper-slide">
                    <a href="desLivros4.html"><img src="<?= _URLBASE_ ?>public/img/imgLivro/Cidades-de-Papel.jpg" alt="livroHarry" title="Livro"></a>
                </div>
                <div class="swiper-slide">
                    <a href="desLivros5.html"><img src="<?= _URLBASE_ ?>public/img/imgLivro/DepoisDeVoce_Jojo.jpg" alt="livroNeve" title="Livro"></a>
                </div>
                <div class="swiper-slide">
                    <a href="desLivros6.html"><img src="<?= _URLBASE_ ?>public/img/imgLivro/livroPercy.jpg" alt="livroPercy" title="Livro"></a>
                </div>
                <div class="swiper-slide">
                    <a href="desLivros7.html"><img src="<?= _URLBASE_ ?>public/img/imgLivro/Livro-A-Culpa-e-das-Estrelas.jpg" alt="livroHarry" title="Livro"></a>
                </div>
                <div class="swiper-slide">
                    <a href="desLivros8.html"><img src="<?= _URLBASE_ ?>public/img/imgLivro/Livro-After.jpg" alt="livroNeve" title="Livro"></a>
                </div>
                <div class="swiper-slide">
                    <a href="desLivros9.html"><img src="<?= _URLBASE_ ?>public/img/imgLivro/Livro-As-Cronicas-de-Gelo-e-Fogo-A-Danca-dos-Dragoes.jpg" alt="livroPercy" title="Livro"></a>
                </div>
            </div>
            <!-- Add Pagination -->
            <div class="swiper-pagination"></div>
        </div>
    </div>
</div>