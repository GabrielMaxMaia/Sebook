<?php
$title = "Melhor agregador de acervos";
//BANNER
require_once  'src/view/user/util/banner.php';
//SWIPER QUEBRADO
require_once  'src/view/user/util/slick.php';
//EVENTOS
require_once 'src/view/user/util/ultimosFeeds.php';
