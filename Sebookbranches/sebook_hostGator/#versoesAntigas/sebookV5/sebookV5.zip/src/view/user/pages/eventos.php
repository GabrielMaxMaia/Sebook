<div id="container">
    <section class="eventos">
        <div class="container">
            <h1>Eventos</h1>
            <figure>
                <div class="img-eventos">
                    <img src="images/img/imgBanner/banner1.jpg" alt="">
                </div>
                <figcaption>
                    Festa do Livro
                </figcaption>
            </figure>
            <p><strong>Local:</strong>É o mesmo das edições anteriores:
                AV. Prof. Mello Morais, travessa C, na cidade universitária, em São Paulo.
            </p>
            <p>
                <strong>Data/Hora:</strong>
                Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                
            </p>
            <p>
                <strong>Discrição:</strong> dolor sit amet consectetur adipisicing elit. 
                Quibusdam voluptates sunt cum possimus harum officia ratione.
                Possimus minus ab error et fuga officiis, eos, nisi expedita,
                totam commodi doloremque vitae?
            </p>

            <hr>
            <figure>
                    <div class="img-eventos">
                        <img src="images/img/imgBanner/banner2.jpg" alt="">
                    </div>
                    <figcaption>
                        Festa do Livro
                    </figcaption>
                </figure>
                <p><strong>Local:</strong>É o mesmo das edições anteriores:
                    AV. Prof. Mello Morais, travessa C, na cidade universitária, em São Paulo.
                </p>
                <p>
                    <strong>Data/Hora:</strong>
                    Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
                   
                </p>
                <p>
                    <strong>Discrição:</strong> dolor sit amet consectetur adipisicing elit. 
                    Quibusdam voluptates sunt cum possimus harum officia ratione.
                    Possimus minus ab error et fuga officiis, eos, nisi expedita,
                    totam commodi doloremque vitae?
                </p>
        </div>
    </section>
    </div>