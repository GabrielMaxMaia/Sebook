<?php
$title = "Politica";
?>
<article class="quemSomos">
    <section class="container">
        <div class="containerText">
            <h1>Politica De Privacidade</h1>
            <p>
            <b>DA PRIVACIDADE:</b><br>
            <b>1.</b>	O Sebook protege a privacidade dos dados cadastrais de seus usuários.
             Todos os dados de cadastro exigidos são de uso restrito da Sebook, exceto
              quando requeridos por autoridade legal competente.<br>
              <b>2.</b>	O Sebook fornece ao(s) ARTESÃO(S) e/ou SEBO(S) PARCEIRO(S) envolvidos 
            somente as informações individuais do LEITOR essenciais para o bom funcionamento
             do processo de doações e de interações através do site.<br>
             <b>3.</b>	O Sebook não executa transações bancárias em sua plataforma, qualquer ato
             relacionado a compras de livros ocorrerá diretamente entre o LEITOR e o SEBO PARCEIRO,
              bem de doações, ocorrerão entre LEITOR e ARTESÃO.<br><br>
            
            <b>DAS PENALIDADES:</b><br>
            <b>1.</b>	O Sebook reserva-se no direito de banir, temporário ou definitivamente, o USUÁRIO no
             caso de descumprimento de qualquer item deste termo.<br><br>
            
            <b>PROPRIEDADE INTELECTUAL:</b><br>
            <b>1.</b>	O LEITOR não poderá utilizar qualquer marca, signo ou sinal distintivo de propriedade,
             ou licenciada à Sebook ou aos SEBOS, ou que faça referência à marca "Sebook" ou marcas 
             conexas,
            salvo autorização expressa por escrito da Sebook e, se for o caso, do licenciante. 
            O disposto nesta cláusula é extensivo às marcas eventualmente depositadas, mas ainda 
            não concedidas à Sebook.<br>
            <b>2.</b>	Caso o LEITOR opte por submeter resenhas de livros, renuncia, desde já, à 
            integralidade dos direitos patrimoniais das resenhas eventualmente submetidas.<br><br>
            
            <b>PRAZOS, ALTERAÇÕES E RESCISÃO:</b><br>
            Os Termos e Condições de Uso entrarão em vigor na data de sua publicação no site.<br>
            O Sebook poderá alterar os Termos e Condições de Uso em qualquer tempo, sem aviso prévio.<br>
            
            
            </p>
        </div>
    </section>
</article>
